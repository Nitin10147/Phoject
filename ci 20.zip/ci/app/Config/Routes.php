<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'AuthenticationController::index');  

 $routes->group('/', ['namespace' => 'App\Controllers'] , static function ($routes) {
    $routes->post('login', 'AuthenticationController::login');
    $routes->post('logout', 'AuthenticationController::logout');
    $routes->post('checkEmailExist', 'AuthenticationController::checkEmailExist');
    $routes->post('sendForgotPassswordlink', 'AuthenticationController::sendForgotPassswordlink');
});

$routes->group('dashboard', ['filter' => 'Auth'],['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'DashboardController::index');  
});

$routes->group('usermaster', ['filter' => 'Auth'],['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'UserMasterController::index');
    $routes->post('addupdate', 'UserMasterController::addupdate');
    $routes->post('view', 'UserMasterController::view');
    $routes->post('delete', 'UserMasterController::delete');
    $routes->post('edit', 'UserMasterController::edit');
});

$routes->group('clientmaster', ['filter' => 'Auth'],['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'ClientMasterController::index');
    
});

$routes->group('itemmaster', ['filter' => 'Auth'],['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'ItemMasterController::index');
});

$routes->group('invoicemaster', ['filter' => 'Auth'], ['namespace' => 'App\Controllers'], static function ($routes) {
    $routes->get('/', 'InvoicemasterController::index');
});





 ?>