<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SanSoftwares</title>
  <?= link_tag(base_url('assets/css/Login.css')); ?>
</head>

<body>

  <main>
    <div class="box">
      <div class="inner-box">
        <div class="forms-wrap">
          <form autocomplete="off" class="sign-in-form" id="loginform" method="POST">
            <!-- <div class="logo">
                <img src="./img/logo.png" alt="easyclass" />
                 <h3>SanSoftwares</h3>
              </div>  -->
            <input type="hidden" id="baseUrl" value="<?php echo base_url(); ?>">
            <div class="heading">
              <h2>Welcome Back</h2>
            </div>

            <div class="actual-form">
              <div class="input-wrap">
                <input type="text" minlength="4" maxlength="30" name="email" class="input-field" autocomplete="off"  />
                <label>Email</label>
              </div>
              <span id="emailError" class="error"></span>

              <div class="input-wrap">
                <input type="password" minlength="4" maxlength="25" name="password" class="input-field" autocomplete="off"  />
                <label>Password</label>
                <span id="passwordError" class="error"></span>
              </div>
             
              <div class="captcha-container container d-flex flex-column">
                <div id="captcha" class="captcha-box"></div>
                <button type="button" class="refresh-btn" id="refreshCaptcha">⟳</button>
                <input type="text"  name="captacha" id="captcha-input" class="input-field" autocomplete="off" placeholder="Enter Captcha"
                   />
              </div>
              <span id="captachaError" class="error"></span>
              


              <button type="submit" value="Sign In" class="sign-btn" >Sign In</button>

              <p class="text">
                Forgotten your password or you login datails?
                <a href="#" class="toggle">Forgot Password</a>
              </p>
            </div>
          </form>

          <form action="" autocomplete="off" id="forgotform" class="sign-up-form" method="POST">
            <div class="heading">
              <h2 style="font-size: 26px;">Forgot Password</h2>
              <!-- <h6>Already have an account?</h6>
                <a href="#" class="toggle">Sign in</a> -->
            </div>

            <div class="actual-form">
              <div class="input-wrap">
                <input type="email" name="email" class="input-field" id="Forgotemail" autocomplete="off" required />
                <label>Email</label>
              </div>
              <button type="submit" value="Sign Up" class="sign-btn" >Send</button>

              <p class="text">
                Already have an account?
                <a href="#" class="toggle">Sign in</a>
              </p>


            </div>
          </form>
        </div>

        <div class="carousel">
          <div class="images-wrapper">
            <img src="<?= base_url('assets/images/image5.avif'); ?>" class="image img-1 show" alt="" />
            <img src="<?= base_url('assets/images/image4.avif'); ?>" class="image img-2" alt="" />
            <img src=" <?= base_url('assets/images/image1.jpg'); ?>" class="image img-3" alt="" />
          </div>

          <div class="text-slider">

          </div>

          <div class="bullets">
            <span class="active" data-value="1"></span>
            <span data-value="2"></span>
            <span data-value="3"></span>
          </div>
        </div>
      </div>
    </div>
    </div>
  </main>
  <?= script_tag(base_url('assets/js/jquery.js')); ?>
  <?= script_tag(base_url('assets/js/Login.js')); ?>
  <?= script_tag(base_url('assets/Lib/sweetalert.min.js')); ?>



</body>

</html>