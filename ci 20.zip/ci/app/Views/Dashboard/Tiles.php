<style>
ol,
ul {
    padding-left: 0px;

}

.container {
    padding: 20px;
}

.card {
    border: none;
    color: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
    width: 100%;
    box-sizing: border-box;
    min-height: 150px;
    display: flex;
    align-items: center;
}

.card:hover {
    transform: scale(1.05);
}

.card-blue {
    background: linear-gradient(135deg, #3b8eff, #559bff);
}

.card-green {
    background: linear-gradient(135deg, #2ecc71, #48c78e);
}

.card-orange {
    background: linear-gradient(135deg, #f39c12, #f5a623);
}

.card-red {
    background: linear-gradient(135deg, #e74c3c, #f15f5d);
}

.icon-space img {
    padding-top: 15px;
    width: 85%;
    max-width: 100px;
    height: auto;
    object-fit: contain;
}

h6 {
    font-size: clamp(16px, 2vw, 18px);
    margin: 0;
}

/* h3 {
    font-size: clamp(20px, 3vw, 30px);
    margin: 0;
} */

.card-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: nowrap;
    gap: 10px;
    width: 100%;
}

@media (max-width: 1200px) {
    .card {
        padding: 15px;
        min-height: 140px;
    }

    .icon-space img {
        max-width: 110px;
    }
}

@media (max-width: 1000px) and (min-width: 769px) {
    .card {
        padding: 12px;
        min-height: 130px;
    }

    .icon-space img {
        max-width: 100px;
    }

    .col-md-3 {
        flex: 0 0 25%;
        max-width: 25%;
    }
}

@media (max-width: 768px) {
    .card {
        padding: 12px;
        min-height: 120px;
    }

    .icon-space img {
        max-width: 90px;
    }

    .col-md-3 {
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media (max-width: 576px) {
    .card {
        padding: 10px;
        min-height: 100px;
    }

    .icon-space img {
        max-width: 70px;
    }

    .col-md-3 {
        flex: 0 0 100%;
        max-width: 100%;
    }

    .card-content {
        flex-direction: column;
        text-align: center;
    }
}
</style>
<div class="container mt-2">
    <div class="row g-3">
        <div class="col-12 col-md-3 tile" data-link="usermaster">
            <div class="card card-blue">
                <div class="card-content">
                    <div>
                        <h6>Users</h6>
                        <h3 id="usersCount">63</h3>
                    </div>
                    <div class="icon-space"><img src="<?= base_url('assets/images/3.png'); ?>" alt="Users Icon"></div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3 tile" data-link="clientmaster">
            <div class="card card-green">
                <div class="card-content">
                    <div>
                        <h6>Client</h6>
                        <h3 id="clientsCount">10</h3>
                    </div>
                    <div class="icon-space"><img src="<?= base_url('assets/images/2.png'); ?>" alt="Clients Icon"></div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3 tile" data-link="itemmaster">
            <div class="card card-orange">
                <div class="card-content">
                    <div>
                        <h6>Items</h6>
                        <h3 id="projectsCount">20</h3>
                    </div>
                    <div class="icon-space"><img src="<?= base_url('assets/images/5.png'); ?>" alt="Items Icon"></div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-3 tile" data-link="invoicemaster">
            <div class="card card-red">
                <div class="card-content">
                    <div>
                        <h6>Invoice</h6>
                        <h4 id="invoicesCount">₹2000</h4>
                        <span style="font-size: 12px;">Total invoices:10</span>
                    </div>
                    <div class="icon-space"><img src=" <?= base_url('assets/images/4.png'); ?>" alt="Invoice Icon"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="row mt-3">
            <div class="col-5 mt-3 text-center" id="pieChart">
                <h5 class="mt-4" id="PieHeading">Invoice Created by Per Client</h5>
        
            </div>
            <div class="col-8 col-md-7 ml-3" id="barChart">
                
            </div>
        </div> -->
</div>

<script>
function animateCount(elementId, targetCount, duration = 10) {
    let currentCount = 0;
    const increment = targetCount / 100;
    const interval = setInterval(function() {
        if (currentCount < targetCount) {
            currentCount += increment;
            $("#" + elementId).text(Math.round(currentCount));
        } else {
            $("#" + elementId).text(targetCount);
            clearInterval(interval);
        }
    }, duration);
}



$(document).ready(function() {
    const $tiles = $('.tile');
    const $sidebarLinks = $('.sidebar-link');

    $tiles.on('click', function() {
        const linkId = $(this).data('link');
        $('.' + linkId + "side").click();
        $sidebarLinks.removeClass('active');
        $('.' + linkId + "side").addClass('active');
    });
});
</script>