<nav class="sb-topnav navbar navbar-expand">
    <a class="navbar-brand ps-3" href="<?= base_url('dashboard') ?>"><img
            src="<?= base_url('assets/images/logo.png'); ?>" alt="" srcset=""></a>
    <button class="btn btn-link  order-1 order-lg-0 me-4 me-lg-0 m-4" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
   
    <ul   class=" navbar-nav d-none d-md-inline-block ms-auto me-0 me-md-3 my-2 my-md-0">
        <li class="nav-item dropdown">
            <a class=" " id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="<?= base_url('assets/images/account.png'); ?>" class="avatar img-fluid" alt="User Avatar">
            </a>

            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="#!"><i class="fa-solid fa-circle-user"></i> Account</a></li>
                <li>
                    <hr class="dropdown-divider" />
                </li>
                <li> <a class="dropdown-item" href="#!"><i class="fa-solid fa-right-from-bracket"></i>Logout</a></li>
            </ul>
        </li>
    </ul>
</nav>



<style>

#sidebarToggle{
    color: white;
    background-color: #0063f7;
    padding : 3px 9px;
    border-radius: 7px;
    box-shadow: rgba(17, 17, 26, 0.1) 0px 0px 16px;
}

.dropdown-menu svg {
    font-size: 17px;
    margin-right: 15px;
}
</style>