<?php

namespace App\Models;

use CodeIgniter\Model;

class AuthenticationModel extends Model
{

    protected $db;

    public function __construct()
    {
        $this->db = db_connect();
    }

    protected $table = 'usermaster';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [];


    // Validation
    protected $validationRules = [];
    protected $validationMessages = [];
    protected $skipValidation = false;
    protected $cleanValidationRules = true;


    public function loginAuth($data)
    {
        try {
            $tableObject = $this->db->table('usermaster');
            $user = $tableObject->where('email', $data['email'])->get()->getRowArray();

            if (!$user) {
                return [
                    'status' => false,
                    'message' => 'Invalid email or password'
                ];
            }
            
         if (md5(trim($data['password'])) !== $user['password']) {
                return [
                    'status' => false,
                    'message' => 'Invalid email or password'
                ];
            }

            unset($user['password']);
            return [
                'status' => true,
                'data' => $user
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }



}
