<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\Exceptions\DatabaseException;

class Usermaster extends Model
{
    protected $table = 'usermaster';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'id',
        'first_name',
        'last_name',
        'email',
        'password',
        'mobile_number',
        'created_by',
        'created_date',
        'modified_by',
        'modified_date',
        'profile_pic'
    ];

    /**
     * Add or Update the Usermaster data
     *
     * @param array $data The data to be inserted or updated
     * @return array Response with status and message
     */
    public function addUpdate(array $data)
    {

        $reqType = $data['req_type'];
        unset($data['req_type']);

        if ($reqType === 'add') {
            return $this->addUser($data);
        } elseif ($reqType === 'update') {
            return $this->updateUser($data);
        }
        return ['status' => false, 'message' => 'Invalid request type'];
    }

    /**
     * Add new Usermaster record
     *
     * @param array $data The data to insert
     * @return array Response with status and message
     */
    private function addUser(array $data)
    {
        unset($data['id']);

        try {
            $this->insert($data);
            return [
                'status' => true,
                'message' => 'Data Inserted Successfully',
                'table_name' => $this->table,
                'id' => $this->db->insertID()
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    /**
     * Update existing Usermaster record
     *
     * @param array $data The data to update
     * @return array Response with status and message
     */
    private function updateUser(array $data)
    {
        $id = $data['id'];
        try {
            $updated = $this->update($id, $data);
            // echo $this->getLastQuery();
            if ($updated) {
                return [
                    'status' => true,
                    'message' => 'Data Updated Successfully',
                    'table_name' => $this->table
                ];
            } else {
                return [
                    'status' => false,
                    'message' => 'No changes were made to the data.',
                    'table_name' => $this->table
                ];
            }
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }


    /**
     * Delete the Usermaster record
     *
     * @param int $id The ID of the record to delete
     * @return array Response with status and message
     */

    public function deleteuser($id)
    {
        try {
            $this->delete($id);
            return [
                'status' => true,
                'message' => 'Data Deleted Successfully',
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }

    public function getuserData($id)
    {
        try {
            $result = $this->where('id', $id)->first();
            return [
                'status' => true,
                'data' => $result,
                'table_name' => $this->table
            ];
        } catch (DatabaseException $e) {
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }























    public function fetch($sort_column1, $sort_order, $page_limit, $offset, $name = '', $email = '', $phone = '')
    {
        try {
            // Use Query Builder in CI4


            $builder = $this->db->table($this->table);  // Start with the table

            // Apply search filters
            if (!empty($name)) {
                $builder->like('first_name', $name);  // Adjusted to first_name as per your schema
            }
            if (!empty($email)) {
                $builder->where('email', $email);
            }
            if (!empty($phone)) {
                $builder->where('mobile_number', $phone);  // Adjusted to mobile_number
            }

            // Apply sorting based on the provided columns
            if (!empty($sort_column1) && !empty($sort_order)) {
                // Removed sorting logic for 'status'
                $builder->orderBy($sort_column1, $sort_order); // Apply the sorting by the first column
            }

            // Apply limit and offset for pagination
            $builder->limit($page_limit, $offset);

            // Get the data
            $data = $builder->get()->getResultArray();
            // Get total count of filtered data (without pagination)
            $countBuilder = clone $builder;  // Clone the builder to avoid affecting the previous query
            $total_count = $countBuilder->countAllResults();
            // Return data and count
            return [
                'count' => $total_count,  // Total count of filtered data
                'data' => $data           // Data for the current page
            ];

        } catch (DatabaseException $e) {
            // Handle any database exceptions
            return [
                'status' => false,
                'message' => 'Database error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        } catch (\Exception $e) {
            // Handle any general exceptions
            return [
                'status' => false,
                'message' => 'Error: ' . $e->getMessage(),
                'table_name' => $this->table
            ];
        }
    }


}
