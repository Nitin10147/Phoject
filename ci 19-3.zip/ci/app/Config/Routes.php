<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'AuthenticationController::index');  

 $routes->group('/', ['namespace' => 'App\Controllers'] , static function ($routes) {
    $routes->post('login', 'AuthenticationController::login');
    $routes->post('logout', 'AuthenticationController::logout');
});

$routes->group('dashboard', ['namespace' => 'App\Controllers'],['filter' => 'Auth'], static function ($routes) {
    $routes->get('/', 'DashboardController::index');  
});

$routes->group('usermaster', ['namespace' => 'App\Controllers'], ['filter' => 'Auth'],static function ($routes) {
    $routes->get('/', 'UserMasterController::index');
    $routes->post('addupdate', 'UserMasterController::addupdate');
    $routes->post('view', 'UserMasterController::view');
    $routes->post('delete', 'UserMasterController::delete');
    $routes->post('edit', 'UserMasterController::edit');
});

$routes->group('clientmaster', ['namespace' => 'App\Controllers'],['filter' => 'Auth'], static function ($routes) {
    $routes->get('/', 'ClientMasterController::index');
    
});

$routes->group('itemmaster', ['namespace' => 'App\Controllers'],['filter' => 'Auth'], static function ($routes) {
    $routes->get('/', 'ItemMasterController::index');
});

$routes->group('invoicemaster', ['namespace' => 'App\Controllers'],['filter' => 'Auth'], static function ($routes) {
    $routes->get('/', 'InvoicemasterController::index');
});





 ?>