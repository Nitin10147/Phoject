<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AuthenticationModel;

class AuthenticationController extends BaseController
{
    public function index(): string
    {
        return view('Login/Login');
    }

    public function login()
    {
        $validation = \Config\Services::validation();
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]'
        ]);
        if (!$validation->run($_POST)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
        $data = [
            'email' => $_POST['email'],
            'password' => $_POST['password']
        ];

        $model = new AuthenticationModel();
        $result = $model->loginAuth($data);

        if ($result['status']) {
            $session = session();
         
            $session->set([
                'username' =>  $result['data']['first_name'].' '.$result['data']['last_name'],
                'profile_pic' => $result['data']['profile_pic'],
                'user_id' => $result['data']['id'],
                'email' => $result['data']['email'],
                'logged_in' => true
            ]);
            return response()->setJSON($result);
        } else {
            return response()->setJSON($result);
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        echo 'logout';
    }
}

?>