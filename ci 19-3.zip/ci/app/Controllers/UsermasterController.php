<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Libraries\formvalidation;

class UsermasterController extends BaseController
{


    public function index()
    {
        return view('Usermaster/usermaster');
    }

    public function addupdate()
    {

      
        $data = $this->request->getPost();
        $table = $data['table'] ?? 'usermaster';
        $formValidation = new Formvalidation();
        $data = $this->request->getPost();
        $result = $formValidation->validate($data, $table);

        if ($result !== true) {
            return $this->response->setJSON(
                [
                    'status' => false,
                    'error' => $result
                ]
            );
        } else {

            if (isset($data['password'])) {
                $data['password'] = md5(trim($data['password']));
            }

            // =========================image Upload ==============================
            helper('upload');
            $file = $this->request->getFile('image');
            // print_r($file);
            if ($file->isValid() && ! $file->hasMoved()) {
                $result = upload_file($file);
                if (isset($result['filename'])) {
                    $data['profile_pic'] = $result['filename'];
                } else {
                    return $this->response->setJSON(
                        [
                            'status' => false,
                            'error' => $result['error']
                        ]
                    );
                }

            }
            $userModel = new \App\Models\Usermaster();
            $result = $userModel->addUpdate($data);
            return $this->response->setJSON($result);
        }


    }


    public function delete()
    {

        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Usermaster();
        $result = $userModel->deleteuser($id);
        return $this->response->setJSON($result);

    }


    public function edit()
    {
        $id = $this->request->getPost('id');
        $userModel = new \App\Models\Usermaster();
        $result = $userModel->getuser($id);
        return $this->response->setJSON($result);
    }

    public function view()
    {
        try {
            // Get POST data
            $page_limit = $this->request->getPost('page_limit') ?? 5;
            $page_no = $this->request->getPost('page') ?? 1;
            $sort_column = $this->request->getPost('column') ?? 'status';
            $sort_order = $this->request->getPost('order') ?? 'DESC';
            $offset = ($page_no - 1) * $page_limit;

            // Optional search fields
            $name = !empty($this->request->getPost('searchname')) ? trim($this->request->getPost('searchname')) : "";
            $email = !empty($this->request->getPost('searchemail')) ? trim($this->request->getPost('searchemail')) : "";
            $phone = !empty($this->request->getPost('searchphone')) ? trim($this->request->getPost('searchphone')) : "";

            $userModel = new \App\Models\Usermaster();
            $queryData = $userModel->fetch($sort_column, $sort_order, $page_limit, $offset, $name, $email, $phone);
            // print_r($queryData);============================
            $result = $queryData['data'];
            $total_records = $queryData['count'];

            // Prepare the table output
            $columns = ['id', 'first_name', 'last_name', 'email', 'mobile_number'];
            $output = '<div class="table-wrap">
                <table class="table table-bordered">
                    <thead class="table-secondary">
                        <tr>
                            <th scope="col" class="text-center" style="width: 50px;">Sr.No</th>';

            foreach ($columns as $column) {
                $new_sort_order = $sort_column == $column && $sort_order == 'ASC' ? 'DESC' : 'ASC';
                $sort_icons = $sort_column == $column && $sort_order == 'ASC' ?
                    '<i class="fa fa-sort-alpha-asc" aria-hidden="true"></i>' :
                    '<i class="fa fa-sort-alpha-desc" aria-hidden="true"></i>';

                $output .= '<th scope="col" class="text-center" style="width: 150px;">
                    <a class="column_sort text-black" href="#" data-column="' . $column . '" data-order="' . $new_sort_order . '" style="align-items: center; gap: 5px;">
                        <span>' . ucfirst($column) . '</span>
                        ' . $sort_icons . '
                    </a>
                </th>';
            }
            $output .= '<th scope="col" class="text-center" style="width: 100px;">ProfilePic</th>';
            $output .= '<th scope="col" class="text-center" style="width: 100px;">Action</th></tr></thead>';

            // Display rows
            if (!empty($result)) {

                $s_no = $offset + 1;
                foreach ($result as $row) {
                    $output .= '<tr>';
                    $output .= '<td class="text-center" style="width: 50px;">' . $s_no++ . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['id'] . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['first_name'] . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['last_name'] . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['email'] . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['mobile_number'] . '</td>';
                    $output .= '<td style="width: 150px;">' . $row['profile_pic'] . '</td>';
                    $output .= '<td class="text-center" style="width: 150px;  display: flex; justify-content: center;  height: auto;">
                        <button class="btn btn-secondary btn-sm edit" data-editid="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
                            <i class="fa fa-pencil" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                        </button>
                        <button class="btn btn-danger btn-sm delete" data-deleteid="' . $row['id'] . '" style="padding: 4px 6px; font-size: 12px;">
                            <i class="fa fa-trash" aria-hidden="true" style="width: 16px; height: 16px;"></i>
                        </button>
                    </td>';
                    $output .= '</tr>';
                }
            } else {
                $output .= '<tr><td colspan="9" class="text-center text-danger bg-secondary font-weight-bold" style="font-size: 16px; background-color: rgba(255, 0, 0, 0.1);">No Data Found</td></tr>';
            }

            $output .= '</tbody></table></div>';
            // Pagination
            // $pager = \Config\Services::pager();
            // $pagination = $pager->makeLinks($page_no, $page_limit, $total_records, '', $page_limit);

            // Return the response
            // Assuming $this->response is properly set

            return $this->response->setJSON([
                'data' => $output,
                // 'pagination' => $pagination,
                'total_records' => $total_records,
                'total_pages' => ceil($total_records / $page_limit)
            ]);






        } catch (\Exception $e) {
            // Handle errors gracefully
            log_message('error', 'Error in fetch method: ' . $e->getMessage());
            echo json_encode(['error' => true, 'message' => 'An unexpected error occurred while fetching user data. Please try again later.']);
        }
    }
}