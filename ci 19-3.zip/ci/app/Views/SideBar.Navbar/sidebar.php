<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion " id="sidenavAccordion">
        <div class="sb-sidenav-menu d-flex flex-column">

            <ul class="sidebar-menu">
                <li class="sidebar-menu-item ">
                    <a href=" <?= base_url('dashboard') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon "><i class="fa-solid fa-house"></i></div>
                        <span class="sidebar-menu-item-link-text">Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('usermaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-users"></i></div>
                        <span class="sidebar-menu-item-link-text">Usermaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('clientmaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        <span class="sidebar-menu-item-link-text">Clientmaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('itemmaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-dice-d6"></i></div>
                        <span class="sidebar-menu-item-link-text">Itemmaster</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?= base_url('invoicemaster') ?>" class="sidebar-menu-item-link">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-file-invoice"></i></div>
                        <span class="sidebar-menu-item-link-text">Invoicemaster</span>
                    </a>
                </li>


                <a class=" mt-auto  text-center" href="#" id="logout">
                    <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i> Logout</div>
                </a>
            </ul>


        </div>
    </nav>
</div>

<script>
    //  ======================This Js is To Make Link Active ==============================
    document.addEventListener("DOMContentLoaded", function () {
        const menuItems = document.querySelectorAll(".sidebar-menu-item-link");

        menuItems.forEach(item => {
            item.addEventListener("click", function () {
                document.querySelectorAll(".sidebar-menu-item").forEach(menu => {
                    menu.classList.remove("active");
                });
                this.closest(".sidebar-menu-item").classList.add("active");
                localStorage.setItem("activeMenu", this.getAttribute("href"));
            });
        });

        const activeMenu = localStorage.getItem("activeMenu");
        if (activeMenu) {
            document.querySelectorAll(".sidebar-menu-item-link").forEach(link => {
                if (link.getAttribute("href") === activeMenu) {
                    link.closest(".sidebar-menu-item").classList.add("active");
                }
            });
        }
    });
    //=======================================================================================
    $(document).on('click', '#logout', function () {
        $.ajax({
            url: '<?= base_url('logout') ?>', // Ensure this is wrapped correctly
            type: 'POST',

            success: function (response) {
                // Redirect to homepage after successful logout
                window.location.href = '<?= base_url('/') ?>';
            },
            error: function (response) {
                // Show error message if something goes wrong
                $('#loginError').text('Something went wrong. Please try again.');
            }
        });
    });

</script>

<style>
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        background-color: white;
        width: 256px;
        height: 100%;
        display: flex;
        flex-direction: column;
        transition-property: width;
        transition-duration: var(--duration-150);

    }

    .sidebar-collapsed .sidebar {
        width: 56px;
    }

    .sidebar-brand {
        height: 48px;
        display: flex;
        align-items: center;
        padding: 0 18px;
        flex-shrink: 0;
        overflow: hidden;
    }

    .sidebar-brand-link {
        text-decoration: none display: flex;
        align-items: center;
    }



    .sidebar-brand-link-text {
        font-weight: 700;
        font-size: var(--text-lg);
        transition-property: opacity;
        transition-duration: var(--duration-150);
    }

    .sidebar-collapsed .sidebar-brand-link-text {
        opacity: 0;
    }

    .sidebar-menu-wrapper {
        overflow-y: hidden;
        min-height: 0;
        height: 100%;
        padding: 16px 0;
        margin-top: 16px;
        display: flex;
        flex-direction: column;
    }

    .sidebar-menu {
        min-height: 95%;
        list-style-type: none;
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
        padding: 0;
        margin-top: 20px;
        margin-bottom: 0px;
    }

    .sidebar-menu-item {
        border-radius: 100px;
        padding-bottom: 10px;
    }

    .sidebar-menu-item-bottom {
        margin-top: auto;
    }

    .sidebar-menu-item.active {
        background-color: var(--neutral-100);
        position: relative;
    }

    .sidebar-menu-item.active::before {
        content: "";
        position: absolute;
        top: -32px;
        right: 0;
        width: 32px;
        height: 32px;
        border-radius: var(--rounded-full);
        pointer-events: none;
        box-shadow: 16px 16px 0 var(--neutral-100);
    }

    .sidebar-menu-item.active::after {
        content: "";
        position: absolute;
        bottom: -32px;
        right: 0;
        width: 32px;
        height: 32px;
        border-radius: var(--rounded-full);
        pointer-events: none;
        box-shadow: 16px -16px 0 var(--neutral-100);
    }

    .sidebar-menu-item-link {
        display: flex;
        align-items: center;
        height: 36px;
        background-color: var(--white);
        border-radius: var(--rounded-full);
        text-decoration: none;
        padding: 0 20px;
        color: var(--neutral-800);
    }



    .sidebar-menu-item.active .sidebar-menu-item-link {
        /* background-color: ; */
        color: white !important;
        transition: 0.3s;
        border-radius: 0 20px 20px 0;
        margin-right: 5px;



        background-color: #4C43CD;
        background-image: radial-gradient(93% 87% at 87% 89%, rgba(0, 0, 0, 0.23) 0%, transparent 86.18%), radial-gradient(66% 87% at 26% 20%, rgba(255, 255, 255, 0.41) 0%, rgba(255, 255, 255, 0) 69.79%, rgba(255, 255, 255, 0) 100%);
        box-shadow: 2px 19px 31px rgba(0, 0, 0, 0.2);
        /* font-weight: bold; */
    }

    .sb-nav-link-icon {
        font-size: var(--text-lg);
        flex-shrink: 0;
        margin-right: 15px;
    }

    .sidebar-menu-item-link-text {
        font-size: 17px;
        font-weight: bold;
        min-width: 0;
        white-space: nowrap;
        overflow: hidden;
    }
</style>