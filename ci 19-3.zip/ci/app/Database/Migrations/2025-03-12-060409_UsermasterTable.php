<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UsermasterTable extends Migration
{

    public function up()
    {
        // column ->[id, first_name ,last_name,email,password,
        //           mobile_number,created_by,created_date,modified_by,modified_date, profile_pic]


        $this->forge->addField(
            [
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true,
                ],
                'first_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'last_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 20,
                    'null' => false,
                ],
                'email' => [
                    'type' => 'VARCHAR',
                    'constraint' => 30,
                    'null' => false,
                ],
                'password' => [
                    'type' => 'VARCHAR',
                    'constraint' => 50,
                    'null' => false,
                ],
                'mobile_number' => [
                    'type' => 'BIGINT',
                    'constraint' => 13,
                    'null' => false,
                ],
                'created_by' => [
                    'type' => 'INT',
                    'constraint' => '11',
                    'null' => false,
                ],
                'created_date' => [
                    'type' => 'DateTime',
                    'null' => false,
                ],
                'modified_by' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ],
                'modified_date' => [
                    'type' => 'DATETIME',
                    'null' => false,
                ],
                'profile_pic' => [
                    'type' => 'VARCHAR',
                    'constraint' => 70,
                    'null' => false,
                ],
            ]
        );
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('email'); 
        $this->forge->addUniqueKey('mobile_number');
        $this->forge->createTable('usermaster');

    }

    public function down()
    {
        $this->forge->dropTable('usermaster');
        
    }
}
