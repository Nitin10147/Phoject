<?php

namespace App\Libraries;

use CodeIgniter\Database\SQLite3\Table;
class Formvalidation
{
    public function validate($data, $table)
    {
       
        $defaultFields = [
            'first_name' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]',
            'last_name' => 'required|trim|min_length[3]|regex_match[/^[a-zA-Z ]+$/]',
            'email' => 'required|trim|valid_email',
            'mobile_number' => 'required|trim|exact_length[10]|numeric'
        ];

      
        $validation = \Config\Services::validation();
    
        $validation->setRules($defaultFields);
        
        if (!$validation->run($data)) {
            return $validation->getErrors(); 
        } else {
            return true;
        }
    }
}
