window.addEventListener('DOMContentLoaded', event => {
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
            document.body.classList.toggle('sb-sidenav-toggled');
        }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains(
                'sb-sidenav-toggled'));
        });
    }

});

//  ======================This Js is To Make Link Active ==============================
document.addEventListener("DOMContentLoaded", function () {
    const sidebarLinks = document.querySelectorAll(".sb-sidenav .nav-link");

    // Function to set active class
    function setActiveLink() {
        let currentPath = window.location.pathname; // Get the current URL path

        sidebarLinks.forEach(link => {
            let linkPath = link.getAttribute("href");
            if (currentPath.includes(linkPath)) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    }

    // Run on page load
    setActiveLink();

    // Add click event listener
    sidebarLinks.forEach(link => {
        link.addEventListener("click", function () {
            sidebarLinks.forEach(l => l.classList.remove("active"));
            this.classList.add("active");
        });
    });
});

//=======================================================================================


// JavaScript to handle the toggle of the search form visibility
document.getElementById('togglerButton').addEventListener('click', function () {
    var searchForm = document.getElementById('searchBarContainer');
    var isCollapsed = searchForm.classList.contains('collapse');

    // Toggle the collapse class
    if (isCollapsed) {
        searchForm.classList.remove('collapse');
        this.innerHTML = '▲ &nbsp Hide Search Form'; // Change button text to indicate collapse
    } else {
        searchForm.classList.add('collapse');
        this.innerHTML = '▼ &nbsp Search Form'; // Change button text to indicate expand
    }
});

